from DIRAC.Core.DISET.RPCClient import RPCClient
from DIRAC.Core.Base import Script
from DIRAC.Resources.Computing.ComputingElement import ComputingElement
from math import *
import threading
import time
import os
import sys

Script.parseCommandLine( )
client = RPCClient('WorkloadManagement/GateService')


endmsg = sys.argv[1]
particle = sys.argv[2]

print 'end is: ', endmsg
print 'le nbr de particule a envoyer est ---> ', particle

workflowid = os.getenv("MOTEUR_WORKFLOWID")
print 'identifiant du Workflow --->', workflowid
jobid = os.getenv("JOBID")
print 'identifiant du job ---> ',jobid

if endmsg=='false':
  check = [workflowid, 'check']
  result = client.echo(str(check))
  if result['Value'] == 'stop':
       	print 'stop of simulation'
	print 'arret de lexecution du job'
	f = open('../std.in','a')
	f.write('stop')
	f.close()
  elif result['Value'] == 'continue':
       	print 'continue the simulation'
	msg= [workflowid,jobid,particle]
	resul = client.echo(str(msg))
        if resul['OK']:
                print 'Success:',resul['Value']
        else:
                 print 'Error:',resul['Message']
  if result['OK']:
	print 'Success:',result['Value']
  else:
	print 'Error:',result['Message']

else:
  finalmsg=[workflowid,'finalmsg',jobid,particle]
  reslt = client.echo(str(finalmsg))
  if reslt['OK']:
	print 'Success:',reslt['Value']
  else:
 	print 'Error:',reslt['Message']


